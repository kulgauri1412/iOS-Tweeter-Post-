//
//  SignUpViewController.swift
//  Demo4
//
//  Created by Gauri Kulkarni on 11/13/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Alamofire

class SignUpViewController: UIViewController,UITextFieldDelegate{

    @IBOutlet weak var FirstName: UITextField!
    @IBOutlet weak var LastName: UITextField!
    @IBOutlet weak var Nickname: UITextField!
    @IBOutlet weak var Email: UITextField!
    @IBOutlet weak var Password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        super.HideKeyboard()
        FirstName.delegate = self
        LastName.delegate = self
        Nickname.delegate = self
        Email.delegate = self
        Password.delegate = self
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func RegisterUser(_ sender: Any) {
        
        let fisrtname = FirstName.text!
        let lastname = LastName.text!
        let nickname = Nickname.text!
        let email = Email.text!
        let password = Password.text!
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: email)
        
        if fisrtname.count < 2 {
            let alert = UIAlertController(title: "Firstname is too short", message: "", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        if lastname.count < 2 {
            let alert = UIAlertController(title: "Lastname is too short", message: "", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        if nickname.count < 2{
            let alert = UIAlertController(title: "Nickname is too short", message: "", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        if result == false{
                let alert = UIAlertController(title: "Please enter valid Email Id", message: "", preferredStyle: UIAlertController.Style.alert)
                     alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                     self.present(alert, animated: true, completion: nil)
            }
        if password.count < 3 {
            let alert = UIAlertController(title: "Password is too short", message: "", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        let parameters: Parameters = [
        "firstname": fisrtname,
        "lastname": lastname,
        "nickname": nickname,
        "email": email,
        "password": password
        ]
        
    Alamofire.request("https://bismarck.sdsu.edu/api/instapost-upload/newuser", method: .post,parameters: parameters, encoding: JSONEncoding.default)
                .validate()
                .responseJSON{ response in
                    switch response.result {
                    case .success:
                        let data = response.result.value as! [ String : String ]
                        print(data)
                        if data["result"] == "fail"{
                            print(data["result"]!)
                            let alert = UIAlertController(title: data["errors"], message: "", preferredStyle: .alert)
                            let cancelAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
                            alert.addAction(cancelAction)
                            self.present(alert, animated: true, completion: nil)
                        }
                        else if data["result"] == "success"{
                            print("success")
                            let alert = UIAlertController(title: "You are registered successfully!", message: "", preferredStyle: .alert)
                            let cancelAction = UIAlertAction(title: "Ok", style: .cancel) { (action) -> Void in
                                let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
                                vc.modalPresentationStyle = .fullScreen
                                self.present(vc, animated: true, completion: nil)
                            }
                            alert.addAction(cancelAction)
                            self.present(alert, animated: true, completion: nil)
                        }
                        
                    case .failure(let error):
                        print(error)
                    }
            }
        
    }
    
}
