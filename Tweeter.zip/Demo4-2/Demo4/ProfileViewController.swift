//
//  ProfileViewController.swift
//  Demo4
//
//  Created by Gauri Kulkarni on 11/17/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON


class ProfileViewController: UIViewController,UITextFieldDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate {

    
    @IBOutlet weak var postText: UITextField!
    @IBOutlet weak var postHashtags: UITextField!
    
    var hashrtags = [String]()
    var userEmail :String = String()
    var userPassword :String = String()
    var myImageBase64:String = String()
    
    @IBOutlet weak var myImageView: UIImageView!
    
    
    
    @IBAction func Logout(_ sender: Any) {
        UserDefaults.standard.removePersistentDomain(forName: "email")
        UserDefaults.standard.removePersistentDomain(forName: "password")
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        vc.modalPresentationStyle = .fullScreen
       self.present(vc, animated: true, completion: nil)
    
    }
    
    @IBAction func pickImage(_ sender: Any) {
       
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing = true
        self.present(imagePicker, animated: true, completion: nil)
    
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage{
                myImageView.image = image
                myImageBase64.removeAll()
                var imageData: Data? = image.jpegData(compressionQuality: 0.4)
                myImageBase64 = imageData?.base64EncodedString() ?? ""
                print(myImageBase64.count)
                imageData?.removeAll()
            }
            self.dismiss(animated: true, completion: nil)
        }

    @IBAction func sharePost(_ sender: Any) {
        let textP = postText.text!
        let textH = postHashtags.text!
        
        var textarray : [String] = textP.components(separatedBy: " ")
        
        hashrtags.removeAll()
        
        for (key,val) in textarray.enumerated().reversed(){
            if val.hasPrefix("#"){
                hashrtags.append(val)
                textarray.remove(at: key)
            }
        }
        
        let newText = textarray.joined(separator: " ")
        
        if textH.count > 0{
            var hashArray : [String] = textH.components(separatedBy: " ")
            
            for (kKey,hval) in hashArray.enumerated().reversed() {
                if hval.hasPrefix("#"){
                    hashrtags.append(hval)
                    hashArray.remove(at: kKey)
                }
            }
        }
        
        
        if newText.count == 0{
            let alert = UIAlertController(title: "Text is required for post!", message: "", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        if textH.count == 0{
            let alert = UIAlertController(title: "Hashtag filed is required for post!", message: "", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        if  newText.count > 144  {
            let alert = UIAlertController(title: "Text is too large! Maximum character limit is 144 please reduce text", message: "", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }
        
        if hashrtags.count > 0 {
            print("inside hash")
            for hash in hashrtags{
                print(hash.count)
                if hash.count < 2 {
                   let alert = UIAlertController(title: "Hashtag must be we with some letters", message: "", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
            
        }
        
        if let email = UserDefaults.standard.object(forKey: "email") as? String, let password = UserDefaults.standard.object(forKey: "password")as? String{
             userEmail = email
             userPassword = password
        }
        
        print(userEmail,userPassword)
//
//           if let decodedImageData = Data(base64Encoded: myImageBase64, options: .ignoreUnknownCharacters) {
//                    let image = UIImage(data: decodedImageData)
//                    myImageView.image = image
//                }
//
        
        //print(myImageBase64)
        
        
        let parameters: Parameters = [
        "email": userEmail,
        "password": userPassword,
        "text": newText,
        "hashtags": hashrtags
        ]

        
        //postImage(400)
        
        if newText.count > 0 && hashrtags.count > 0 && textH.count > 0{
            Alamofire.request("https://bismarck.sdsu.edu/api/instapost-upload/post", method: .post,parameters: parameters, encoding: JSONEncoding.default)
                .validate()
                .responseJSON{ response in
                    switch response.result {
                    case .success:
                        if let data = response.result.value{
                            print(data)
                            let jsonVal = JSON(data)
                            if jsonVal["result"].stringValue == "success"{
                                let postId = jsonVal["id"].intValue
                                //print(self.myImageBase64.count)
                                if !self.myImageBase64.isEmpty{

                                    print("inside to call function")
                                    
                                    self.postText.text = nil
                                    self.postHashtags.text = nil
                                    
                                    self.postImage(postId){ error in

                                        if error == nil {
                                            print("image posted successfully!")
                                            return
                                        }

                                        print("failed!")
                                    }

                                }
                                else{
                                    let alert = UIAlertController(title: "Your post successfully uploaded!", message: "", preferredStyle: .alert)
                                    let cancelAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
                                    alert.addAction(cancelAction)
                                    self.present(alert, animated: true, completion: nil)
                                }

                            }
                            else if jsonVal["result"].stringValue == "fail"{
                                let alert = UIAlertController(title: "Something went wrong please try agian!", message: "", preferredStyle: .alert)
                                let cancelAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
                                alert.addAction(cancelAction)
                                self.present(alert, animated: true, completion: nil)
                            }
                        }


                    case .failure(let error):
                        print(error)
                    }
            }
        }
        else{
            
            let alert = UIAlertController(title: "Text filed and hashtag files are required for post!", message: "", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }
        
        

        
//       base64 to image decode
//        if let decodedImageData = Data(base64Encoded: myImageBase64, options: .ignoreUnknownCharacters) {
//            let image = UIImage(data: decodedImageData)
//            myImageView.image = image
//        }
        


       // myImageView.image = nil
// //       myImageBase64.removeAll()
       
    }
    
    
    

    
    func postImage(_ imageId:Int,completion: @escaping (Error?)-> Void){
        
        
        //print(myImageBase64)
        //myImageBase64.removeAll()
        
        let parameters: Parameters = [
        "email": userEmail,
        "password": userPassword,
        "image": myImageBase64,
        "post-id": imageId
        ]
        
        print("Image size: \(myImageBase64.count)")
        
        Alamofire.request("https://bismarck.sdsu.edu/api/instapost-upload/image", method: .post,parameters: parameters, encoding: JSONEncoding.default)
                    .validate()
                    .responseJSON{ response in
                        switch response.result {
                        case .success:
                            if let data = response.result.value{
                                print(data)
                                let jsonVal = JSON(data)
                                if jsonVal["result"].stringValue == "success"{

                                    self.myImageBase64.removeAll()
                                    self.myImageView.image = nil
                                    
                                    
                                    let alert = UIAlertController(title: "Your post successfully uploaded!", message: "", preferredStyle: .alert)
                                    let cancelAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
                                    alert.addAction(cancelAction)
                                    self.present(alert, animated: true, completion: nil)
                                    
                                    completion(nil)
                                    return
                                    
                                }
                                else if jsonVal["result"].stringValue == "fail"{
                                    let alert = UIAlertController(title: "Something went wrong please try agian!", message: "", preferredStyle: .alert)
                                    let cancelAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
                                    alert.addAction(cancelAction)
                                    self.present(alert, animated: true, completion: nil)
                                    print("error!")
                                    completion(nil)
                                    return
                                    
                                }
                            }


                        case .failure(let error):
                            print(error)
                        }
                }
            
        
    }
    
    @IBOutlet weak var selectedImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        super.HideKeyboard()
        postText.delegate = self
        postHashtags.delegate = self
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
           textField.resignFirstResponder()
           return true
       }
    

}

//extension ProfileViewController : UINavigationControllerDelegate,UIImagePickerControllerDelegate{
//
//    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
//        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage{
//            myImageView.image = image
//            let imageData: Data? = image.jpegData(compressionQuality: 0.4)
//            myImageBase64 = imageData?.base64EncodedString(options: .lineLength64Characters) ?? ""
//            //myImageBase64 = String(image.pngData()?.base64EncodedData() ?? "")
//           // myImageBase64 = image?.base64EncodedString(options: .lineLength64Characters) ?? ""
//        }
//        self.dismiss(animated: true, completion: nil)
//    }
//}


