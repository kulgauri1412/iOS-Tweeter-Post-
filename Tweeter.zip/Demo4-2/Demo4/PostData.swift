//
//  PostData.swift
//  
//
//  Created by Gauri Kulkarni on 11/16/19.
//

import Foundation
import SwiftyJSON

class PostData{
    
    var postid = Int()
    var text = String()
    var ratingCount = Int()
    var ratingAvrg = Double()
    var hastag = [String]()
    var comments = [String]()
    var imageid = Int()
    
    init(postJson:JSON) {
        self.postid = postJson["id"].intValue
        self.text = postJson["text"].stringValue
        self.ratingCount = postJson["ratings-count"].intValue
        self.ratingAvrg = postJson["ratings-average"].doubleValue
        self.hastag = postJson["hashtags"].arrayObject as! [String]
        self.comments = postJson["comments"].arrayObject as! [String]
        self.imageid = postJson["image"].intValue
        
    }

}
