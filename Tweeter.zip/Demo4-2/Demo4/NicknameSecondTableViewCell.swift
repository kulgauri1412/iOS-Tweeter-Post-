//
//  NicknameSecondTableViewCell.swift
//  Demo4
//
//  Created by Gauri Kulkarni on 11/21/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit

protocol buttonCommentNickname {
    func CommentPost(postid : Int)
    func RatePost(ratepostid : Int)
}


class NicknameSecondTableViewCell: UITableViewCell {
    
    @IBOutlet weak var postText: UILabel!
    
    @IBOutlet weak var postHashtag: UILabel!

    
    var comment:buttonCommentNickname?
    var postid : Int = 0
    var ratepostid :Int = 0
    
    
    @IBAction func btnComment(_ sender: Any) {
        self.comment?.CommentPost(postid: postid)
    }
    
    @IBAction func btnRate(_ sender: Any) {
        self.comment?.RatePost(ratepostid: ratepostid)
    }
    
    @IBOutlet weak var ratings: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
