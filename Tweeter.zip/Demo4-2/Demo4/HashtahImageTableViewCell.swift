//
//  HashtahImageTableViewCell.swift
//  Demo4
//
//  Created by Gauri Kulkarni on 11/20/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit

protocol buttonCommentHashImage {
    func imageComment(postid : Int)
}

class HashtahImageTableViewCell: UITableViewCell {
    
   
    @IBOutlet weak var postText: UILabel!
    
    @IBOutlet weak var postHashtag: UILabel!
    
    @IBOutlet weak var postImage: UIImageView!
    
    @IBOutlet weak var lblRatings: UIButton!
    
    var comment:buttonCommentHashImage?
    var postid : Int = 0
    
    @IBAction func commentImagePost(_ sender: Any) {
        self.comment?.imageComment(postid: postid)
    }
    
//    @IBAction func commentPost(_ sender: Any) {
//        self.comment?.imageComment(sender: self)
//    }
//    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
