//
//  ViewController.swift
//  Demo4
//
//  Created by Gauri Kulkarni on 11/13/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Alamofire

extension UIViewController{
    func HideKeyboard(){
        let Tap:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(DismissKeyboard))
        
        view.addGestureRecognizer(Tap)
    }
    @objc func DismissKeyboard(){
        view.endEditing(true)
    }
}

class ViewController: UIViewController,UITextFieldDelegate{


    @IBOutlet weak var UserEmail: UITextField!
    @IBOutlet weak var UserPassword: UITextField!
    
    
    @IBAction func InstaLogin(_ sender: Any) {
 
        let password = UserPassword.text!
        let email = UserEmail.text!
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: email)

        if result == false{
            let alert = UIAlertController(title: "Please enter valid Email Id", message: "", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        if password.count < 3{
            let alert = UIAlertController(title: "Please enter correct password", message: "", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        let url = "https://bismarck.sdsu.edu/api/instapost-query/authenticate?email="+email+"&password="+password
        
        
        Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
                     .validate()
                     .responseJSON{ response in
                         switch response.result {
                         case .success:
                            let data = response.result.value as! [String:Int]
                            print(data)
                             for d in data{
                                if d.value == 0{
                                    print("error")
                                    let alert = UIAlertController(title: "Alert!", message: "Your Email or Password is not correct. If you are new a user click on the Sign Up button to register yourself", preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                                else{
                                    print("success");
//                                    self.performSegue(withIdentifier: "MainTabController", sender: self)
                                    
                                    UserDefaults.standard.set(email, forKey: "email")
                                    UserDefaults.standard.set(password,forKey: "password")
                                    
                                    let main = UIStoryboard(name: "Main", bundle: nil)
                                    let mainTBC = main.instantiateViewController(withIdentifier: "MainTabController")
                                    
                                    mainTBC.modalPresentationStyle = .fullScreen 
                                    self.present(mainTBC,animated:true,completion: nil)
                                    
                                }
                            }

                             
                         case .failure(let error):
                             print(error)
                         }
                 }
     
        
    }
    
    
    
    @IBAction func InstaSignUp(_ sender: Any) {
        
        performSegue(withIdentifier: "signup", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
       
       super.HideKeyboard()
       UserEmail.delegate = self
       UserPassword.delegate = self
        Alamofire.request("https://bismarck.sdsu.edu/api/instapost-query/service-calls").responseString { response in guard response.error == nil else {
                print("Error")
                return
            
            }
            if let data = response.result.value{
                print(data)
            }
            
        }

    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }


}
