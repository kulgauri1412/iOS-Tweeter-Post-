//
//  NicknameListViewController.swift
//  Demo4
//
//  Created by Gauri Kulkarni on 11/15/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class NicknameListViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet weak var NicknameTableView: UITableView!
    
    //var nickName : [[String:Any]] = []
    var nickN = [String]()
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return nickN.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let nicknamecell = tableView.dequeueReusableCell(withIdentifier: "nicknamecell", for: indexPath) as! NicknameTableViewCell
        
        let eachnick = nickN[indexPath.row]
        nicknamecell.UserNickname.text = eachnick

        return nicknamecell
    }
    

    
    func showPostOnNickname(sender : NicknameTableViewCell){
        let showname = sender.tag
        let  a = nickN[showname]
        print(a)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         DispatchQueue.main.async {[weak self] in
            let vc = self?.storyboard?.instantiateViewController(identifier: "NicknamePostController") as! NicknamePostController
            vc.nickname = (self?.nickN[indexPath.row])!
        self?.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        getNickName()
        
    }
    
    func getNickName(){
        let url = "https://bismarck.sdsu.edu/api/instapost-query/nicknames";
             
             Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
                 .validate().responseJSON{ response in
                     switch response.result {
                     case .success:
                         if  let responseValue = response.result.value{
                             
                             let jsonVal = JSON(responseValue)
                          //   print(jsonVal["nicknames"].arrayValue)
                             let nickVal = jsonVal["nicknames"].arrayValue
                             for val in nickVal{
                                 
                                 let usernicknameVal = val.stringValue
                                 self.nickN.append(usernicknameVal)
                             }
                               
                         }
                         self.NicknameTableView.reloadData()
                      
                     case .failure(let error):
                             print(error)
                     }
             }
    }
    

}
