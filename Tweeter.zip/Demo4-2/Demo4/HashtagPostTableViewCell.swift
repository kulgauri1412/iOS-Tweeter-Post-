//
//  HashtagPostTableViewCell.swift
//  Demo4
//
//  Created by Gauri Kulkarni on 11/20/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit

protocol buttonCommentHash {
    func CommentPost(postid : Int)
    func ratingPost(postid : Int)
}

class HashtagPostTableViewCell: UITableViewCell {
    
    @IBOutlet weak var postText: UILabel!
    
    var comment:buttonCommentHash?
    var postid : Int = 0
    
    
    @IBOutlet weak var lblRating: UIButton!
    
    @IBAction func btnRating(_ sender: Any) {
        
        self.comment?.ratingPost(postid: postid)
    }
    
    @IBAction func commentPost(_ sender: Any) {
        self.comment?.CommentPost(postid: postid)
    }
    
    @IBOutlet weak var postHashtag: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    

}
