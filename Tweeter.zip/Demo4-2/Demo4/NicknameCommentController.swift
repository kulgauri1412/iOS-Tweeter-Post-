//
//  NicknameCommentController.swift
//  Demo4
//
//  Created by Gauri Kulkarni on 11/22/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class NicknameCommentController: UIViewController,UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource {
   
    
    var commentPostid = Int()
    var allcomments = [String]()
    var revComment = [String]()
    var hashtags = [String]()
    
    var userEmail = String()
    var userPassword = String()
    
    @IBOutlet weak var commentTabelView: UITableView!
    @IBOutlet weak var commentText: UILabel!
    @IBOutlet weak var commentHashtags: UILabel!
    
    @IBOutlet weak var commentTextField: UITextField!
    
    
    @IBAction func btnRatePost(_ sender: Any) {
        print(commentPostid)
        let popvc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "RatingViewController") as! RatingViewController
        popvc.postid = commentPostid
        self.addChild(popvc)
        popvc.view.frame = self.view.frame
        self.view.addSubview(popvc.view)
        popvc.didMove(toParent: self)
    }
    
    
    @IBAction func commentPost(_ sender: Any) {
        let comment = commentTextField.text!
              
              if comment.count < 1{
                  
                  let alert = UIAlertController(title: "Comment field is required!", message: "", preferredStyle: UIAlertController.Style.alert)
                  alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                  self.present(alert, animated: true, completion: nil)
                  
              }
              
              if let email = UserDefaults.standard.object(forKey: "email") as? String, let password = UserDefaults.standard.object(forKey: "password")as? String{
                        userEmail = email
                        userPassword = password
                   }
                   
              print(userEmail,userPassword)
              
              let parameters: Parameters = [
                     "email": userEmail,
                     "password": userPassword,
                     "comment": comment,
                     "post-id": commentPostid
                     ]
        
          if comment.count > 1{
            Alamofire.request("https://bismarck.sdsu.edu/api/instapost-upload/comment", method: .post,parameters: parameters, encoding: JSONEncoding.default)
                            .validate().responseJSON{ response in
                                switch response.result {
                                    case .success:
                                        if  let responseValue = response.result.value{
                                           let jsonVal = JSON(responseValue)
                                            if jsonVal["result"].stringValue == "success" {
                                                
                                                self.getComments(){error in
                                                    if error == nil{
                                                        self.commentTextField.text = ""
                                                        let alert = UIAlertController(title: "Your comment  successfully posted!", message: "", preferredStyle: .alert)
                                                        let cancelAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
                                                        alert.addAction(cancelAction)
                                                        self.present(alert, animated: true, completion: nil)
                                                    }
                                                    else{
                                                        print("something wend wrong")
                                                    }
                                                }
                                                
                                            }
                                            else if jsonVal["result"].stringValue == "fail"{
                                                let alert = UIAlertController(title: "Alert!", message: "Something went wrong,try again!", preferredStyle: .alert)
                                                let cancelAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
                                                alert.addAction(cancelAction)
                                                self.present(alert, animated: true, completion: nil)
                                            }
                                                         
                                        }
                                    case .failure(let error):
                                        print(error)
                                }
                        }
                }
              
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allcomments.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let commentNickname = tableView.dequeueReusableCell(withIdentifier: "nicknameComment", for: indexPath) as! NicknameCommentCell
        
        revComment = allcomments.reversed()
        
        let data = revComment[indexPath.row]
        
        commentNickname.postcomment.text = data
        
        return commentNickname
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(commentPostid)
        super.HideKeyboard()
        commentTextField.delegate = self

        getAllComments()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
           textField.resignFirstResponder()
           return true
       }
    
    func getComments(completion: @escaping (Error?)-> Void){
        let url = "https://bismarck.sdsu.edu/api/instapost-query/post?post-id=\(commentPostid)";
                              
        Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
            .validate().responseJSON{ response in
                switch response.result {
                    case .success:
                        if  let responseValue = response.result.value{
                                                                 
                        let jsonVal = JSON(responseValue)
                        let comments = jsonVal["post"]["comments"].arrayValue
                            self.allcomments.removeAll()
                            for comment in comments{
                            let cm = comment.stringValue
                            self.allcomments.append(cm)
                            }
                                            
                            self.commentTabelView.reloadData()
                            completion(nil)
                            return
                                              
                            }
                        case .failure(let error):
                            print(error)
                        }
                }
    }
    
    func getAllComments(){
           let url = "https://bismarck.sdsu.edu/api/instapost-query/post?post-id=\(commentPostid)";
                          
                          Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
                              .validate().responseJSON{ response in
                                  switch response.result {
                                  case .success:
                                       if  let responseValue = response.result.value{
                                                             
                                          let jsonVal = JSON(responseValue)
    //                                      let singlepost = PostData(postJson: jsonVal["post"])
    //                                      self.allPosts.append(singlepost)
                                          let comments = jsonVal["post"]["comments"].arrayValue
                                          let posttext =  jsonVal["post"]["text"].stringValue
                                          self.commentText.text = posttext
                                        let postHash = jsonVal["post"]["hashtags"].arrayValue
                                        for hashtag in postHash{
                                            let hash = hashtag.stringValue
                                            self.hashtags.append(hash)
                                        }
                                        let allHashIntext = self.hashtags.joined(separator: " ")
                                        self.commentHashtags.text = allHashIntext
                                        for comment in comments{
                                            let cm = comment.stringValue
                                            self.allcomments.append(cm)
                                        }
                                        
                                          self.commentTabelView.reloadData()
                                          
                                      }
                                  case .failure(let error):
                                          print(error)
                                  }
                          }
        }

}
