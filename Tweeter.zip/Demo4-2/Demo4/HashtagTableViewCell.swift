//
//  HashtagTableViewCell.swift
//  Demo4
//
//  Created by Gauri Kulkarni on 11/19/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit

class HashtagTableViewCell: UITableViewCell {

    
    @IBOutlet weak var HshtagName: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
