//
//  NicknamePostController.swift
//  Demo4
//
//  Created by Gauri Kulkarni on 11/16/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class NicknamePostController: UIViewController,UITableViewDelegate,UITableViewDataSource,buttonCommentNickname,buttonCommentNicknameImage {
   
//    deinit {
//        print("No retain cycle/leak")
//    }
    
    var nickname = "";
    var postIds = [Int]()
    var postID : Int = Int()
    var allPosts : [PostData] = []
    var image = [String]()
    var imageString = ""
    
    var refresh = UIRefreshControl()
    var activityIndicator : UIActivityIndicatorView = UIActivityIndicatorView()
    
  
    @IBOutlet weak var NickPostTable: UITableView!
    
    
    @IBAction func btnRefresh(_ sender: Any) {
        allPosts.removeAll()
        
        DispatchQueue.global(qos: .userInitiated).async {
            [weak self] in
            guard let strongSelf = self else { return }
                   // Call your function here
                strongSelf.getAllPostIds()
                   DispatchQueue.main.async {
                       // Update UI
                    strongSelf.NickPostTable.reloadData()
                    self?.imageString = ""
                    URLCache.shared.removeAllCachedResponses()
                   }
               }
       
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        getAllPostIds()
      
    }
    


    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allPosts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let nicknamePost = tableView.dequeueReusableCell(withIdentifier: "postcell", for: indexPath) as! NicknPostTableViewCell
        
        let nicknameSecond = tableView.dequeueReusableCell(withIdentifier: "postcellsecond", for: indexPath) as! NicknameSecondTableViewCell
        
        let data = allPosts[indexPath.row]
        
        let tags = data.hastag.joined(separator: " ")
       
        if data.imageid == -1{
            
            nicknameSecond.postText.text = data.text
            nicknameSecond.postHashtag.text = tags
            nicknameSecond.ratings.text = "Ratings " + String((data.ratingAvrg).rounded())
            
            nicknamePost.postImage.image = nil
            
            nicknameSecond.comment = self
            nicknameSecond.postid = data.postid
            nicknameSecond.ratepostid = data.postid
            
            return nicknameSecond
            
        }
        if data.imageid != -1{
            
            nicknamePost.postid.text = data.text
            nicknamePost.txt.text = tags
            nicknamePost.lblRating.text = "Ratings " + String((data.ratingAvrg).rounded())

            DispatchQueue.main.async {[weak self] in
                self?.getimage(data.imageid)
                    if var decodedImageData = Data(base64Encoded: self!.imageString  , options: .ignoreUnknownCharacters) {
                    //print(self!.imageString.count)
                    let image = UIImage(data: decodedImageData)
                    nicknamePost.postImage.image = image
                    //self?.imageString = ""
                    decodedImageData.removeAll()
                }

            }


        }
        
        nicknamePost.comment = self
        nicknamePost.postidImage = data.postid
        
        return nicknamePost
    }
    
    func getimage(_ id : Int){
        let url = "https://bismarck.sdsu.edu/api/instapost-query/image?id=\(id)";
//        activityIndicator.center = self.view.center
//        activityIndicator.hidesWhenStopped = true
//        activityIndicator.style = UIActivityIndicatorView.Style.large
//        view.addSubview(activityIndicator)
//        activityIndicator.startAnimating()

            Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
                        .validate().responseJSON{ response in
                            switch response.result {
                            case .success:
                                if  let responseValue = response.result.value{
                                    
                                    let jsonVal = JSON(responseValue)
                                    
                                    self.imageString = jsonVal["image"].stringValue
                                    //self.activityIndicator.stopAnimating()
                                    //print(self.imageString.count)
                                    //print("Attemt to fetch image")
                                    //self.activityIndicator.stopAnimating()
                                
                                }
                            case .failure(let error):
                                    print(error)
                            }
                    }
    }
    
    func CommentPost(postid: Int) {
        DispatchQueue.main.async {[weak self] in
            let vc = self?.storyboard?.instantiateViewController(identifier: "NicknameCommentController") as! NicknameCommentController
         vc.commentPostid = postid
            self?.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func CommentPostImage(postidImage: Int) {
          let vc = storyboard?.instantiateViewController(identifier: "NicknameCommentController") as! NicknameCommentController
          vc.commentPostid = postidImage
          self.navigationController?.pushViewController(vc, animated: true)
       }
    
    func RatePost(ratepostid postid : Int){
       // print(postid)
        let popvc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "RatingViewController") as! RatingViewController
        popvc.postid = postid
        self.addChild(popvc)
        popvc.view.frame = self.view.frame
        self.view.addSubview(popvc.view)
        popvc.didMove(toParent: self)

    }
       
    
    func getAllPostIds(){
    
        let url = "https://bismarck.sdsu.edu/api/instapost-query/nickname-post-ids?nickname="+nickname;
        
        Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
            .validate().responseJSON{ response in
                switch response.result {
                case .success:
                    if  let responseValue = response.result.value{
                        
                        let jsonVal = JSON(responseValue)
                        //print(jsonVal["ids"])
                        let pids = jsonVal["ids"].arrayValue
                        for ids in pids{
                            let id = ids.intValue
                            //self.postIds.append(id)
                            
                            
                            DispatchQueue.main.async {[weak self] in
                                // Update UI
                             self?.getAllPosts(id)
                            }

                        }
                         
                        
                    }
                 
                case .failure(let error):
                        print(error)
                }
        }
    }
    
    func getAllPosts(_ id :Int){
        
        let url = "https://bismarck.sdsu.edu/api/instapost-query/post?post-id=\(id)";
        
        Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
            .validate().responseJSON{ response in
                switch response.result {
                case .success:
                     if  let responseValue = response.result.value{
                                           
                        let jsonVal = JSON(responseValue)
                        let singlepost = PostData(postJson: jsonVal["post"])
                        self.allPosts.append(singlepost)
                        
                        self.NickPostTable.reloadData()
                        
//                        completion(nil)
//                        return
                        
                    }
                case .failure(let error):
                        print(error)
                }
        }
    }

    

}
