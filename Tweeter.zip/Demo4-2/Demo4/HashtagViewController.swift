//
//  HashtagViewController.swift
//  Demo4
//
//  Created by Gauri Kulkarni on 11/19/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class HashtagViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var HashTagView: UITableView!
    
    var hashTags = [String]()
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return hashTags.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let hashTagcell = tableView.dequeueReusableCell(withIdentifier: "hashtagcell", for: indexPath) as! HashtagTableViewCell
        
        let eachHashtag = hashTags[indexPath.row]
        hashTagcell.HshtagName.text = eachHashtag

        return hashTagcell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //HashtagPostController
        let vc = storyboard?.instantiateViewController(identifier: "HashtagPostController") as! HashtagPostController
        vc.hashtag = hashTags[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getAllHashtags()
        // Do any additional setup after loading the view.
    }
    
    func getAllHashtags(){
        let url = "https://bismarck.sdsu.edu/api/instapost-query/hashtags";
        
        Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
            .validate().responseJSON{ response in
                switch response.result {
                case .success:
                    if  let responseValue = response.result.value{
                        
                        let jsonVal = JSON(responseValue)
                        let nickVal = jsonVal["hashtags"].arrayValue
                        for val in nickVal{
                            
                            let hashtagNames = val.stringValue
                            self.hashTags.append(hashtagNames)
                        }
                          
                    }
                    self.HashTagView.reloadData()
                 
                case .failure(let error):
                        print(error)
                }
        }
        
    }
    

}
