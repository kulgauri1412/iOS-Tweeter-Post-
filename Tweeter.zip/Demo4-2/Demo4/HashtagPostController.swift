//
//  HashtagPostController.swift
//  Demo4
//
//  Created by Gauri Kulkarni on 11/20/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class HashtagPostController: UIViewController,UITableViewDelegate,UITableViewDataSource,buttonCommentHashImage,buttonCommentHash {
    
    var hashtag = ""
    var postIds = [Int]()
    var postID : Int = Int()
    var allPosts : [PostData] = []
    var image = [String]()
    var imageString = ""
    
    
    @IBOutlet weak var HashTagPost: UITableView!

    
    @IBAction func btnRefresh(_ sender: Any) {
     allPosts.removeAll()
     
     DispatchQueue.global(qos: .userInitiated).async {
         [weak self] in
         guard let strongSelf = self else { return }
                // Call your function here
             strongSelf.getAllPostIds()
                DispatchQueue.main.async {
                    // Update UI
                 strongSelf.HashTagPost.reloadData()
                 self?.imageString = ""
                 URLCache.shared.removeAllCachedResponses()
                }
            }
    
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allPosts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let hashtagImageCell = tableView.dequeueReusableCell(withIdentifier: "hashtagpostcellImage", for: indexPath) as! HashtahImageTableViewCell
        
        let hashtagCell = tableView.dequeueReusableCell(withIdentifier: "hashtagpostcell", for: indexPath) as! HashtagPostTableViewCell
        
        let data = allPosts[indexPath.row]
        
        let tags = data.hastag.joined(separator: " ")
     
        if data.imageid == -1{
            
            hashtagCell.postText.text = data.text
            hashtagCell.postHashtag.text = tags
            
            hashtagImageCell.postImage.image = nil
            hashtagCell.lblRating.setTitle("Ratings \(String((data.ratingAvrg).rounded()))", for: .normal)
            
            hashtagCell.comment = self
            hashtagCell.postid = data.postid
            
            return hashtagCell
        }
        if data.imageid != -1{
             hashtagImageCell.postText.text = data.text
               hashtagImageCell.postHashtag.text = tags
            hashtagImageCell.lblRatings.setTitle("Ratings \(String((data.ratingAvrg).rounded()))", for: .normal)
            
            self.getImage(data.imageid){ error in
                if error == nil {
                    if let decodedImageData = Data(base64Encoded: self.imageString, options: .ignoreUnknownCharacters) {
                                let image = UIImage(data: decodedImageData)
                        hashtagImageCell.postImage.image = image
                    }
                }
                if error != nil {
                 print("error occur")
                }

            }

        }
        
        hashtagImageCell.comment = self
        hashtagImageCell.postid = data.postid
       
        
        return hashtagImageCell
        
    }
    
   func imageComment(postid: Int) {
        //print(postid)
    let vc = storyboard?.instantiateViewController(identifier: "HashtagCommentViewController") as! HashtagCommentViewController
    vc.hashtagPostid = postid
    self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func CommentPost(postid : Int){
        //print(postid)
        let vc = storyboard?.instantiateViewController(identifier: "HashtagCommentViewController") as! HashtagCommentViewController
        vc.hashtagPostid = postid
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func ratingPost(postid: Int) {
        let popvc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "RatingViewController") as! RatingViewController
        popvc.postid = postid
        self.addChild(popvc)
        popvc.view.frame = self.view.frame
        self.view.addSubview(popvc.view)
        popvc.didMove(toParent: self)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getAllPostIds()
    }
    
    
     func getAllPostIds(){
       
        
        let newString = hashtag.replacingOccurrences(of: "#", with: "%23")
        
        
           let url = "https://bismarck.sdsu.edu/api/instapost-query/hashtags-post-ids?hashtag="+newString
           
           Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
               .validate().responseJSON{ response in
                   switch response.result {
                   case .success:
                       if  let responseValue = response.result.value{
                           
                           let jsonVal = JSON(responseValue)
                           //print(jsonVal["ids"])
                           let pids = jsonVal["ids"].arrayValue
                           for ids in pids{
                               let id = ids.intValue
                               self.postIds.append(id)
                               self.getAllPosts(id)
                           }
                          
                       }
                    
                   case .failure(let error):
                           print(error)
                   }
           }
       }
    
    
    func getAllPosts(_ postId:Int){
        
        let url = "https://bismarck.sdsu.edu/api/instapost-query/post?post-id=\(postId)";
                
                Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
                    .validate().responseJSON{ response in
                        switch response.result {
                        case .success:
                             if  let responseValue = response.result.value{
                                                   
                                let jsonVal = JSON(responseValue)
                                let singlepost = PostData(postJson: jsonVal["post"])
                                self.allPosts.append(singlepost)
                                
                                self.HashTagPost.reloadData()
                                
                            }
                        case .failure(let error):
                                print(error)
                        }
                }
        
        }
    

    
    func getImage(_ imageid:Int,completion: @escaping (Error?)-> Void){
           
            let url = "https://bismarck.sdsu.edu/api/instapost-query/image?id=\(imageid)";
                   
                   Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
                       .validate().responseJSON{ response in
                           
                           //print("Attempting to retrieve image")
                           
                           switch response.result {
                           case .success:
                               if  let responseValue = response.result.value{
                                   
                                   let jsonVal = JSON(responseValue)
                                   //print(jsonVal["image"])
                                   self.imageString = jsonVal["image"].stringValue
                                   
                                   completion(nil)
                                   return
                               }
                            
                           case .failure(let error):
                                   print(error)
                           }
                   }
       }
   

}
