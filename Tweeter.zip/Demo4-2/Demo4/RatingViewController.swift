//
//  RatingViewController.swift
//  Demo4
//
//  Created by Gauri Kulkarni on 11/22/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class RatingViewController: UIViewController {

    var postid = Int()
    
    var rate = 2
    var userEmail = String()
    var userPassword = String()
    
    @IBOutlet weak var ratelabel: UILabel!
    
   
    @IBAction func btnRatePost(_ sender: Any) {
        
        print(rate)
        
        if let email = UserDefaults.standard.object(forKey: "email") as? String, let password = UserDefaults.standard.object(forKey: "password")as? String{
                userEmail = email
                userPassword = password
        }
                         
        print(userEmail,userPassword)
        
        let parameters: Parameters = [
            "email": userEmail,
            "password": userPassword,
            "rating": rate,
            "post-id": postid
        ]
        
       Alamofire.request("https://bismarck.sdsu.edu/api/instapost-upload/rating", method: .post,parameters: parameters, encoding: JSONEncoding.default)
                   .validate()
                   .responseJSON{ response in
                       switch response.result {
                       case .success:
                        if  let responseValue = response.result.value{
                            let jsonVal = JSON(responseValue)
                            if jsonVal["result"].stringValue == "success"{
                                print("rating done")
                            }
                            else if jsonVal["result"].stringValue == "fail"{
                                print("rating fail")
                            }
                        }
                       case .failure(let error):
                           print(error)
                       }
               }
  
    }
    
    @IBAction func rateslider(_ sender: UISlider) {
        ratelabel.text = String(Int(sender.value))
        rate = Int(sender.value)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        print(postid)
        
       
        // Do any additional setup after loading the view.
    }
    @IBAction func dismiss(_ sender: Any) {
        
        self.view.removeFromSuperview()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
