//
//  HashtagCommentViewController.swift
//  Demo4
//
//  Created by Gauri Kulkarni on 11/20/19.
//  Copyright © 2019 Gauri Kulkarni. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class HashtagCommentViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate {
    
    var hashtagPostid = Int()
   // var allPosts : [PostData] = []
    var allcomments = [String]()
    var revComment = [String]()
    var hashtags = [String]()
    
    @IBOutlet weak var commentTabelview: UITableView!
    @IBOutlet weak var commentPost: UITextField!
    
    @IBOutlet weak var postText: UILabel!
    @IBOutlet weak var postHashtag: UILabel!
    
    var userEmail = String()
    var userPassword = String()
    
    
    @IBAction func btnRate(_ sender: Any) {
        
        let popvc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(identifier: "RatingViewController") as! RatingViewController
        popvc.postid = hashtagPostid
        self.addChild(popvc)
        popvc.view.frame = self.view.frame
        self.view.addSubview(popvc.view)
        popvc.didMove(toParent: self)
        
    }
    
    @IBAction func BtnPostComment(_ sender: Any) {
        
        let comment = commentPost.text!
        
        if comment.count < 1{
            
            let alert = UIAlertController(title: "Comment field is required!", message: "", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }
        
        if let email = UserDefaults.standard.object(forKey: "email") as? String, let password = UserDefaults.standard.object(forKey: "password")as? String{
                  userEmail = email
                  userPassword = password
             }
             
        print(userEmail,userPassword)
        
        let parameters: Parameters = [
               "email": userEmail,
               "password": userPassword,
               "comment": comment,
               "post-id": hashtagPostid
               ]
        
        if comment.count > 1{
        
                Alamofire.request("https://bismarck.sdsu.edu/api/instapost-upload/comment", method: .post,parameters: parameters, encoding: JSONEncoding.default)
                    .validate().responseJSON{ response in
                        switch response.result {
                            case .success:
                                if  let responseValue = response.result.value{
                                   let jsonVal = JSON(responseValue)
                                    if jsonVal["result"].stringValue == "success" {
                                        
                                        self.getComments(){error in
                                            if error == nil{
                                                self.commentPost.text = ""
                                                
//                                                let alert = UIAlertController(title: "Your comment  successfully posted!", message: "", preferredStyle: .alert)
//                                                let cancelAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
//                                                alert.addAction(cancelAction)
//                                                self.present(alert, animated: true, completion: nil)
                                            }
                                            else{
                                                print("something wend wrong")
                                            }
                                        }
                                        
                                    }
                                    else if jsonVal["result"].stringValue == "fail"{
                                        let alert = UIAlertController(title: "Alert!", message: "Something went wrong,try again!", preferredStyle: .alert)
                                        let cancelAction = UIAlertAction(title: "Ok", style: .cancel, handler: nil)
                                        alert.addAction(cancelAction)
                                        self.present(alert, animated: true, completion: nil)
                                    }
                                                 
                                }
                            case .failure(let error):
                                print(error)
                        }
                }
        }
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allcomments.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let commentHash = tableView.dequeueReusableCell(withIdentifier: "commenthashcell", for: indexPath) as! HashtagCommentCell
        
        revComment = allcomments.reversed()
        
        let data = revComment[indexPath.row]
        commentHash.postcomment.text = data
        
        return commentHash
    }
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        super.HideKeyboard()
        commentPost.delegate = self
        
        print(hashtagPostid)
        getAllComments()
        
        
        // Do any additional setup after loading the view.
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
           textField.resignFirstResponder()
           return true
       }
    
    func getComments(completion: @escaping (Error?)-> Void){
        let url = "https://bismarck.sdsu.edu/api/instapost-query/post?post-id=\(hashtagPostid)";
                              
        Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
            .validate().responseJSON{ response in
                switch response.result {
                    case .success:
                        if  let responseValue = response.result.value{
                                                                 
                        let jsonVal = JSON(responseValue)
                        let comments = jsonVal["post"]["comments"].arrayValue
                            self.allcomments.removeAll()
                            for comment in comments{
                            let cm = comment.stringValue
                            self.allcomments.append(cm)
                            }
                                            
                            self.commentTabelview.reloadData()
                            completion(nil)
                            return
                                              
                            }
                        case .failure(let error):
                            print(error)
                        }
                }
    }
    
    func getAllComments(){
       let url = "https://bismarck.sdsu.edu/api/instapost-query/post?post-id=\(hashtagPostid)";
                      
                      Alamofire.request(url, method: .get, encoding: JSONEncoding.default)
                          .validate().responseJSON{ response in
                              switch response.result {
                              case .success:
                                   if  let responseValue = response.result.value{
                                                         
                                      let jsonVal = JSON(responseValue)
//                                      let singlepost = PostData(postJson: jsonVal["post"])
//                                      self.allPosts.append(singlepost)
                                      let comments = jsonVal["post"]["comments"].arrayValue
                                      let posttext =  jsonVal["post"]["text"].stringValue
                                      self.postText.text = posttext
                                    let postHash = jsonVal["post"]["hashtags"].arrayValue
                                    for hashtag in postHash{
                                        let hash = hashtag.stringValue
                                        self.hashtags.append(hash)
                                    }
                                    let allHashIntext = self.hashtags.joined(separator: " ")
                                    self.postHashtag.text = allHashIntext
                                    for comment in comments{
                                        let cm = comment.stringValue
                                        self.allcomments.append(cm)
                                    }
                                    
                                      self.commentTabelview.reloadData()
                                      
                                  }
                              case .failure(let error):
                                      print(error)
                              }
                      }
    }
    

}
